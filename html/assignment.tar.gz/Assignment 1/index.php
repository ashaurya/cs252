<!DOCTYPE html>
<html>
<head>
  <title>Assignment 1</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script>
 function myFun() {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("modal-title").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET", "action.php?q=" + document.getElementById("optionA").value, true);
        xmlhttp.send();
	}

function read() {
	window.location.href = "./src/read.php";
}
function deletes() {
	var roll = document.getElementById('roll-del').value;
	window.location.href = "./src/delete.php?q="+roll;
}
function create() {
	var name = document.getElementById('form-name').value;
	var dob = document.getElementById('form-dob').value;
	var roll = document.getElementById('form-roll').value;
	var reg = document.getElementById('form-reg').value;
	var cpi = document.getElementById('form-cpi').value;

	var getreq = "name=" + name + "&dob=" + dob + "&roll=" + roll + "&reg=" + reg + "&cpi=" + cpi;

	window.location.href = "./src/create.php?"+getreq;
	
}
function update() {
	var roll = document.getElementById('roll-del').value;
	window.location.href = "./src/update.php?q="+roll;
}
 </script>
</head>

<body>
<div align="center">
<h3>Assignment 1</h3>
<br>
<h4>Select an action to continue. <?php echo 'test data' ?> </h4>
<br>
</div>

<div class="container" align="center">

<form id="options" action="" method="post">
<select required autofocus id="optionA" class="btn" name="optionA">
<option value="Create" name="create">Create</option>
<option value="Read" name="read">Read</option>
<option value="Update" name="update">Update</option>
<option value="Delete" name="delete">Delete</option>
</select>
<!--button type="submit" class="btn btn-info btn-lg" action="home.php">Submit</button-->
<br><br>
<!-- Trigger the modal with a button -->
<button type="button" onclick="myFun()" id="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Submit</button>
</form>
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">
		<span id="modal-title"></span>
<!--
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button-->
        </div>
      </div>
      
    </div>
  </div>
  
</div>


</body>
</html>
